<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dodaj nowy plik</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('admin.files.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($file)): ?>
                                <input type="text" hidden id="parent_id" name="parent_id" value="<?php echo e($file->id); ?>">
                            <?php endif; ?>
                            <div class="mb-3">
                                <label for="file" class="form-label">Plik</label>
                                <input type="file" class="form-control" id="file" name="file">
                            </div>
                            <?php if($file->id == null): ?>
                            <div class="mb-3">
                                <label for="category" class="form-label">Dział</label>
                                <select name="category" id="category" class="form-control">
                                    <option value="0" disabled hidden selected>Wybierz dział</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            <div class="mb-3">
                                <label for="description" class="form-label">Opis</label>
                                <input type="text" class="form-control" id="description" name="description" placeholder="Enter the file description"
                                       value="<?php echo e(old('description')); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="type" class="form-label">Typ</label>
                                <input type="text" class="form-control" id="type" name="type" type placeholder="Enter the type of file" value="<?php echo e(old('type')); ?>">
                            </div>
                            <div class="">
                                <button type="submit" class="btn btn-primary">Dodaj</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/files/create.blade.php ENDPATH**/ ?>