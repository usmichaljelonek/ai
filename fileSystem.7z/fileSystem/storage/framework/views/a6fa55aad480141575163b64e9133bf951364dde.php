<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e($category->name); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php $__empty_1 = true; $__currentLoopData = $category->files->where('parent_id',null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card w-100 mb-3 <?php if($file->is_read == 0): ?> border-info <?php endif; ?>">
                                <div class="card-body d-flex justify-content-between">
                                    <h5 class="card-title"><?php echo e($file->name); ?></h5>
                                    <form action="<?php echo e(route('admin.files.download',$file->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-info"><?php echo e($file->file_name); ?></button>
                                    </form>
                                </div>
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $file->subfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex justify-content-between"><?php echo e($subfile->name); ?>

                                           <form action="<?php echo e(route('admin.files.download',$subfile->id)); ?>" method="POST">
                                               <?php echo csrf_field(); ?>
                                               <button type="submit" class="btn btn-info"><?php echo e($subfile->file_name); ?></button>
                                           </form>
                                       </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td>Nie dodano plików</td>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/user/category/show.blade.php ENDPATH**/ ?>