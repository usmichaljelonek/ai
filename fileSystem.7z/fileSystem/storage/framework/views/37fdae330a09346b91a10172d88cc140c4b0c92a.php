<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">File lists</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-end mb-2">
                            <a href="<?php echo e(route('admin.files.create')); ?>">Add new file</a>
                        </div>
                        <table class="table table-stripped">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <thead>
                                <tr>
                                    <th colspan="5"><?php echo e($category->name); ?></th>
                                </tr>
                                </thead>
                                <tbody class="">
                                <tr>
                                    <th>No.</th>
                                    <th>Filename</th>
                                    <th>Descriptions</th>
                                    <th>Type</th>
                                    <th>Options</th>
                                </tr>
                                <?php $__currentLoopData = $category->files->where('parent_id',null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($file->name); ?><br>
                                            <a href="<?php echo e(route('admin.files.create',$file->id)); ?>">Add a subfile</a><br>
                                        </td>
                                        <td><?php echo e($file->description); ?></td>
                                        <td><?php echo e($file->type); ?></td>
                                        <td class="d-flex flex-wrap">
                                            <form action="<?php echo e(route('admin.files.destroy',$file->id)); ?>" method="POST">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn-danger">Delete</button>
                                            </form>
                                            <form action="<?php echo e(route('admin.files.download',$file->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn-info">Download</button>
                                            </form>
                                            <br>
                                        </td>
                                    </tr>
                                    <?php if($file->subfiles): ?>
                                        <?php $__currentLoopData = $file->subfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td></td>
                                                <td><?php echo e($subfile->name); ?></td>
                                                <td><?php echo e($subfile->description); ?></td>
                                                <td><?php echo e($subfile->type); ?></td>
                                                <td class="d-flex">
                                                    <form action="<?php echo e(route('admin.files.destroy',$subfile->id)); ?>" method="POST">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn-danger">Delete</button>
                                                    </form>
                                                    <form action="<?php echo e(route('admin.files.download',$subfile->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn-info">Download</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dkempa/web/fileSystems/resources/views/admin/files/index.blade.php ENDPATH**/ ?>