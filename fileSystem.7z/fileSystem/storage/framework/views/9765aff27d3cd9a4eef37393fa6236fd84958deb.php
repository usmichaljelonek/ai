<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Give rights to user: <?php echo e($user->name); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('admin.user.save.rights',$user->name)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="<?php echo e($category->id); ?>" id="<?php echo e($category->name); ?>" name="categories[]"<?php echo e(in_array($category->id,$rights) ? 'checked' : ''); ?>


                                    >
                                    <label class="form-check-label" for="flexCheckDefault">
                                        <?php echo e($category->name); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-primary">Save rights</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dkempa/web/fileSystems/resources/views/admin/rights/show.blade.php ENDPATH**/ ?>