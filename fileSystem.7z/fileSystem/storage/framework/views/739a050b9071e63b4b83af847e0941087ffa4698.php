<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">O profilu</div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session('msg')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('msg')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('err')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('err')); ?>

                                </div>
                            <?php endif; ?>
                            <form action="<?php echo e(route('user.change.password',Auth::user()->name)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Bieżące hasło</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Enter the current password">
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Nowe hasło</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter the new password">
                                </div>
                                <div class="mb-3">
                                    <label for="password_confirmation" class="form-label">Potwierdź nowe hasło</label>
                                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Enter the new password confirmation ">
                                </div>
                                <div class="">
                                    <button type="submit" class="btn btn-primary">Zmień</button>
                                </div>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/user/show.blade.php ENDPATH**/ ?>