@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">O profilu</div>
                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if (session('msg'))
                                <div class="alert alert-success">
                                    {{ session('msg') }}
                                </div>
                            @endif
                            @if (session('err'))
                                <div class="alert alert-danger">
                                    {{ session('err') }}
                                </div>
                            @endif
                            <form action="{{route('user.change.password',Auth::user()->name)}}" method="POST">
                                @csrf
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Bieżące hasło</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Enter the current password">
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Nowe hasło</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter the new password">
                                </div>
                                <div class="mb-3">
                                    <label for="password_confirmation" class="form-label">Potwierdź nowe hasło</label>
                                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Enter the new password confirmation ">
                                </div>
                                <div class="">
                                    <button type="submit" class="btn btn-primary">Zmień</button>
                                </div>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
