@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ $category->name }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        @forelse($category->files->where('parent_id',null) as $file)
                            <div class="card w-100 mb-3 @if($file->is_read == 0) border-info @endif">
                                <div class="card-body d-flex justify-content-between">
                                    <h5 class="card-title">{{ $file->name}}</h5>
                                    <form action="{{route('admin.files.download',$file->id)}}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-info">{{ $file->file_name }}</button>
                                    </form>
                                </div>
                                <ul class="list-group list-group-flush">
                                    @foreach($file->subfiles as $subfile)
                                        <li class="list-group-item d-flex justify-content-between">{{ $subfile->name }}
                                           <form action="{{route('admin.files.download',$subfile->id)}}" method="POST">
                                               @csrf
                                               <button type="submit" class="btn btn-info">{{ $subfile->file_name }}</button>
                                           </form>
                                       </li>
                                    @endforeach
                                </ul>
                            </div>
                        @empty
                            <td>Nie dodano plików</td>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
