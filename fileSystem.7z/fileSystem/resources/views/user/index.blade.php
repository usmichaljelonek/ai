@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Pulpit') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        <div class="d-flex justify-content-between flex-wrap">
                            @forelse($rights as $right)
                                <a href="{{ route('category.show',$right->categories->name) }}" class="mb-3">
                                    <div class="card" style="width: 18rem;">
                                        <div class="card-body">
                                            <p class="card-text">{{ $right->categories->name }}</p>
                                        </div>
                                    </div>
                                </a>
                            @empty
                                <p>Nie masz przypisanych działów</p>
                            @endforelse
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
