@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dodaj nowy plik</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form action="{{route('admin.files.store')}}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @if(isset($file))
                                <input type="text" hidden id="parent_id" name="parent_id" value="{{ $file->id }}">
                            @endif
                            <div class="mb-3">
                                <label for="file" class="form-label">Plik</label>
                                <input type="file" class="form-control" id="file" name="file">
                            </div>
                            @if($file->id == null)
                            <div class="mb-3">
                                <label for="category" class="form-label">Dział</label>
                                <select name="category" id="category" class="form-control">
                                    <option value="0" disabled hidden selected>Wybierz dział</option>
                                    @foreach($categories as $category)
                                        <option value="{{$category->id}}">{{ $category->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            @endif
                            <div class="mb-3">
                                <label for="description" class="form-label">Opis</label>
                                <input type="text" class="form-control" id="description" name="description" placeholder="Enter the file description"
                                       value="{{ old('description') }}">
                            </div>
                            <div class="mb-3">
                                <label for="type" class="form-label">Typ</label>
                                <input type="text" class="form-control" id="type" name="type" type placeholder="Enter the type of file" value="{{ old('type') }}">
                            </div>
                            <div class="">
                                <button type="submit" class="btn btn-primary">Dodaj</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
