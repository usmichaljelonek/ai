@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Lista plików</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <div class="d-flex justify-content-end mb-2">
                            <a href="{{route('admin.files.create')}}">Dodaj nowy plik</a>
                        </div>
                        <table class="table table-stripped">
                            @foreach($categories as $category)
                                <thead>
                                <tr>
                                    <th colspan="5">{{$category->name}}</th>
                                </tr>
                                </thead>
                                <tbody class="">
                                <tr>
                                    <th>Nr</th>
                                    <th>Nazwa</th>
                                    <th>Opis</th>
                                    <th>Typ</th>
                                    <th>Opcje</th>
                                </tr>
                                @foreach($category->files->where('parent_id',null) as $file)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $file->name }}<br>
                                            <a href="{{ route('admin.files.create',$file->id) }}">Dodaj załącznik</a><br>
                                        </td>
                                        <td>{{ $file->description }}</td>
                                        <td>{{ $file->type }}</td>
                                        <td class="d-flex flex-wrap">
                                            <form action="{{route('admin.files.destroy',$file->id)}}" method="POST">
                                                @method('DELETE')
                                                @csrf
                                                <button type="submit" class="btn-danger">Usuń</button>
                                            </form>
                                            <form action="{{route('admin.files.download',$file->id)}}" method="POST">
                                                @csrf
                                                <button type="submit" class="btn-info">Pobierz</button>
                                            </form>
                                            <br>
                                        </td>
                                    </tr>
                                    @if($file->subfiles)
                                        @foreach($file->subfiles as $subfile)
                                            <tr>
                                                <td></td>
                                                <td>{{ $subfile->name }}</td>
                                                <td>{{ $subfile->description }}</td>
                                                <td>{{ $subfile->type }}</td>
                                                <td class="d-flex">
                                                    <form action="{{route('admin.files.destroy',$subfile->id)}}" method="POST">
                                                        @method('DELETE')
                                                        @csrf
                                                        <button type="submit" class="btn-danger">Usuń</button>
                                                    </form>
                                                    <form action="{{route('admin.files.download',$subfile->id)}}" method="POST">
                                                        @csrf
                                                        <button type="submit" class="btn-info">Pobierz</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @endif
                                @endforeach
                                </tbody>
                            @endforeach


                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
