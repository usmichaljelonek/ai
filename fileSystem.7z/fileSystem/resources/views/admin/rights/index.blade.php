@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Lista działów</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <div class="d-flex justify-content-end mb-2">
                            <a href="{{route('admin.users.create')}}">Dodaj nowego użytkownika</a>
                        </div>
                        <table class="table table-stripped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nazwa użytkownika</th>
                                <th>Email</th>
                                <th>Uprawnienia</th>
                                <th>Opcje</th>
                            </tr>
                            </thead>
                            <tbody>
                                @foreach($users as $user)
                                    <tr>
                                        <td>{{ $user->id }}</td>
                                        <td>{{ $user->name}}</td>
                                        <td>{{ $user->email}}</td>
                                        <td>
                                            @forelse($user->rights as $right)
                                                {{ $right->categories->name }}
                                            @empty
                                                -
                                            @endforelse
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.user.rights',$user->name) }}">Edytuj</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
