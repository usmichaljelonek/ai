@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Nadaj uprawnienia dla: {{ $user->name}}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <form action="{{route('admin.user.save.rights',$user->name)}}" method="POST">
                            @csrf
                            @foreach($categories as $category)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="{{ $category->id }}" id="{{ $category->name }}" name="categories[]"{{ in_array($category->id,$rights) ? 'checked' : '' }}

                                    >
                                    <label class="form-check-label" for="flexCheckDefault">
                                        {{ $category->name }}
                                    </label>
                                </div>
                            @endforeach
                            <button type="submit" class="btn btn-primary">Zapisz</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
