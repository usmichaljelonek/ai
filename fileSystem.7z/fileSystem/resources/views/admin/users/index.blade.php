@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Lista działów</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <div class="d-flex justify-content-end mb-2">
                            <a href="{{route('admin.users.create')}}">Dodaj nowego użytkownika</a>
                        </div>
                        <table class="table table-stripped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nazwa</th>
                                <th>Email</th>
                                <th>Aktywny</th>
                                <th>Opcje</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($users as $user)
                                <tr>
                                    <td>{{$user->id}}</td>
                                    <td>{{$user->name}}</td>
                                    <td>{{$user->email}}</td>
                                    <td>{{$user->is_active == 1 ? 'Aktywny' : 'Nieaktywny'}}</td>
                                    <td class="d-flex">
                                        <form action="{{route('admin.users.activate',$user->name)}}" method="POST">
                                            @csrf
                                            <button type="submit">
                                                {{ $user->is_active == 1 ? 'Dekatywuj' : 'Aktywuj' }}
                                            </button>
                                        </form>
                                        <form action="{{route('admin.users.destroy',$user->name)}}" method="POST">
                                            @method('DELETE')
                                            @csrf
                                            <button type="submit">Usuń</button>
                                        </form>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td>No categories <a href="{{ route('admin.users.create') }}">Dodaj nowego użytkownika</a></td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
