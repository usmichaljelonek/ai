<?php

use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::middleware(['auth'])->group(function () {

    // ------ ADMIN ------ //

    // CATEGORIES
    Route::get('/admin/dashboard', [App\Http\Controllers\Admin\AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('/admin/categories', [\App\Http\Controllers\Admin\CategoryController::class, 'index'])->name('admin.categories');
    Route::get('/admin/categories/create', [\App\Http\Controllers\Admin\CategoryController::class, 'create'])->name('admin.categories.create');
    Route::post('/admin/categories', [\App\Http\Controllers\Admin\CategoryController::class, 'store'])->name('admin.categories.store');
    Route::delete('/admin/categories/{category}', [\App\Http\Controllers\Admin\CategoryController::class, 'destroy'])->name('admin.categories.destroy');

    //FILES
    Route::get('/admin/files', [App\Http\Controllers\Admin\FilesController::class, 'index'])->name('admin.files');
    Route::get('/admin/files/create/{file?}', [\App\Http\Controllers\Admin\FilesController::class, 'create'])->name('admin.files.create');
    Route::post('/admin/files', [\App\Http\Controllers\Admin\FilesController::class, 'store'])->name('admin.files.store');
    Route::delete('/admin/files/{file}', [\App\Http\Controllers\Admin\FilesController::class, 'destroy'])->name('admin.files.destroy');
    Route::post('/admin/files/{file}', [\App\Http\Controllers\Admin\FilesController::class, 'download'])->name('admin.files.download');

    //USERS
    Route::get('/admin/users', [App\Http\Controllers\Admin\UserController::class, 'index'])->name('admin.users');
    Route::get('/admin/users/create', [\App\Http\Controllers\Admin\UserController::class, 'create'])->name('admin.users.create');
    Route::post('/admin/users', [\App\Http\Controllers\Admin\UserController::class, 'store'])->name('admin.users.store');
    Route::delete('/admin/users/{user}', [\App\Http\Controllers\Admin\UserController::class, 'destroy'])->name('admin.users.destroy');
    Route::post('/admin/users/{user}/activate', [\App\Http\Controllers\Admin\UserController::class, 'activate'])->name('admin.users.activate');

    //RIGHTS
    Route::get('/admin/rights', [App\Http\Controllers\Admin\RightsController::class, 'index'])->name('admin.rights');
    Route::get('/admin/rights/{user}', [App\Http\Controllers\Admin\RightsController::class, 'rights'])->name('admin.user.rights');
    Route::post('/admin/rights/{user}', [App\Http\Controllers\Admin\RightsController::class, 'saveRights'])->name('admin.user.save.rights');



    // ------ USER ------ //

    //CATEGORIES

    Route::get('dashboard',[\App\Http\Controllers\Front\UserController::class,'index'])->name('dashboard');
    Route::get('categories/{category}',[\App\Http\Controllers\Front\UserController::class,'showCategories'])->name('category.show');

    //USERS

    Route::get('/profile/{user}', [App\Http\Controllers\Front\UserController::class, 'show'])->name('user.profile');
    Route::post('/profile/{user}', [App\Http\Controllers\Front\UserController::class, 'changePassword'])->name('user.change.password');
});




