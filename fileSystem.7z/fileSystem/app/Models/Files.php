<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Files extends Model
{
    use HasFactory;

    protected $fillable = ['category_id','parent_id','name','description','type','file_name','file_extension','file_size'];


    public function categories()
    {
       return $this->belongsTo(Categories::class,'category_id','id');
    }

    public function subfiles()
    {
        return $this->hasMany(self::class,'parent_id','id');
    }
}
