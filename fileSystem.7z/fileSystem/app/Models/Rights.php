<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rights extends Model
{
    protected $fillable = ['user_id','category_id'];

    protected $casts = ['category_id' => 'array'];

    use HasFactory;

    public function categories()
    {
        return $this->belongsTo(Categories::class,'category_id','id');
    }

    public function users()
    {
        return $this->belongsTo(User::class,'user_id','id');
    }

}
