<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Categories;
use App\Models\Rights;
use App\Models\User;
use Illuminate\Http\Request;

class RightsController extends Controller
{
    public function index()
    {
        $users = User::all();

        return view('admin.rights.index', compact('users'));
    }

    public function rights(User $user)
    {
        $categories = Categories::all();
        $rights = Rights::with(['categories'])->where('user_id','=',$user->id)->pluck('category_id')->toArray();


        return view('admin.rights.show', compact('categories','rights','user'));
    }

    public function saveRights(Request $request, User $user)
    {
        Rights::where('user_id',$user->id)->delete();

        $categories = $request->input('categories');

        foreach ($categories as $category) {
            Rights::create([
                'user_id' => $user->id,
                'category_id' => (int)$category
            ]);
        }

        return redirect()->route('admin.rights');

    }


}
