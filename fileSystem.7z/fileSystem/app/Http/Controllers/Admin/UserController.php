<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    public function index()
    {
        $users = User::all();

        return view('admin.users.index',compact('users'));
    }

    public function create()
    {
        return view('admin.users.create');
    }

    public function store(UserRequest $request)
    {
        $validated = $request->validated();

        User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => Hash::make($request->input('password'),),
        ]);

        return redirect()->route('admin.users');
    }

    public function activate(User $user)
    {
        if($user->isActivate()){
            $user->is_active = 0;
        }
        else{
            $user->is_active = 1;
        }
        $user->save();

        return redirect()->route('admin.users');
    }

    public function destroy(User $user)
    {
        User::destroy($user->id);

        return redirect()->route('admin.users');
    }
}
