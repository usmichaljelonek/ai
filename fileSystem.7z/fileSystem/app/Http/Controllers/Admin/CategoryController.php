<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use App\Models\Categories;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Categories::all();
        return view('admin.categories.index',compact('categories'));
    }

    public function create()
    {
        return view('admin.categories.create');
    }

    public function store(CategoryRequest $request)
    {
        $validated = $request->validated();

        Categories::create($request->all());

        return redirect()->route('admin.categories')->with('Category added.');
    }

    public function destroy(Categories $category)
    {
        Categories::destroy($category->id);

        return redirect()->route('admin.categories');
    }
}
