<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\FileRequest;
use App\Models\Categories;
use App\Models\Files;
use Illuminate\Support\Facades\Storage;

class FilesController
{
    public function index()
    {
        $categories = Categories::get();
        $subfiles = Files::with('subfiles')->get();

        return view('admin.files.index',compact('categories','subfiles'));
    }

    public function create(?Files $file)
    {
        $categories = Categories::all();
        return view('admin.files.create',compact('categories','file'));
    }

    public function store(FileRequest $request)
    {
        $validated = $request->validated();
        $file = $request->file;
        $fileName = $file->getClientOriginalName();
        $fileCategory = Files::where('id',$request->input('parent_id'))->first();



        Files::create([
           'category_id' => $request->input('category') ?? $fileCategory->categories->id,
           'parent_id' => $request->input('parent_id') ,
           'name' => strtok($request->file->getClientoriginalName(),'.'),
           'description' => $request->input('description'),
           'type' => $request->input('type'),
           'file_name' => $fileName,
           'file_extension' => $file->getClientOriginalExtension(),
           'file_size' => $file->getSize()
       ]);

       Storage::putFileAs("files",$file,$fileName);

       return redirect()->route('admin.files');
    }

    public function destroy(Files $file)
    {
        Storage::delete($file->file_name);
        Files::destroy($file->id);

        return redirect()->route('admin.files');
    }

    public function download(Files $file)
    {
        $file->is_read = 1;
        $file->save();
        return Storage::download('files/'.$file->file_name);

    }

}
