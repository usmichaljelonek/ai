<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\UserRequest;
use App\Models\Categories;
use App\Models\Rights;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        $rights = Rights::with(['categories'])->where('user_id','=',Auth::user()->id)->get();

        return view('user.index',compact('rights'));
    }

    public function show(User $user)
    {
        return view('user.show',compact($user));
    }

    public function showCategories(Categories $category)
    {
        return view('user.category.show',compact('category'));
    }

    public function changePassword(ChangePasswordRequest $request,User $user)
    {
        $validate = $request->validated();

        if(Hash::check($request->input('current_password'),$user->password)){
            $user->password = Hash::make($request->input('password'),);
            $user->save();
            return redirect()->route('user.profile',$user->name)->with('msg','Password has been changed');
        }
        return redirect()->route('user.profile',$user->name)->with('err','Current password is invalid');

    }

}
